import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/meal_log.dart';
import '../providers/food_provider.dart';
import '../providers/meal_log_provider.dart';

class MealLoggingPage extends StatefulWidget {
  const MealLoggingPage({super.key});

  @override
  State<MealLoggingPage> createState() => _MealLoggingPageState();
}

class _MealLoggingPageState extends State<MealLoggingPage> {
  int? selectedFoodId;
  String selectedMealType = 'Breakfast';

  final servingsController = TextEditingController(text: '1');
  final priceController = TextEditingController();

  @override
  void dispose() {
    servingsController.dispose();
    priceController.dispose();
    super.dispose();
  }

  Future<void> saveMeal() async {
    final foodProvider = context.read<FoodProvider>();
    final mealProvider = context.read<MealLogProvider>();

    final servings = double.tryParse(servingsController.text);
    final price = double.tryParse(priceController.text);

    if (selectedFoodId == null ||
        servings == null ||
        servings <= 0 ||
        price == null ||
        price < 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter valid meal information.')),
      );
      return;
    }

    final selectedFood = foodProvider.foods.firstWhere(
      (food) => food.id == selectedFoodId,
    );

    final meal = MealLog(
      foodId: selectedFood.id!,
      foodName: selectedFood.name,
      mealType: selectedMealType,
      servings: servings,
      pricePaid: price,
      dateEaten: DateTime.now(),
    );

    await mealProvider.addMealLog(meal);

    if (!mounted) return;

    if (mealProvider.errorMessage != null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(mealProvider.errorMessage!)));
      return;
    }

    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('Meal saved successfully!')));

    servingsController.text = '1';
    priceController.clear();
  }

  @override
  Widget build(BuildContext context) {
    final foodProvider = context.watch<FoodProvider>();
    final mealProvider = context.watch<MealLogProvider>();
    final theme = Theme.of(context);
    final colors = theme.colorScheme;

    final sectionTitleStyle = theme.textTheme.titleMedium?.copyWith(
      fontWeight: FontWeight.w700,
    );
    final fieldLabelStyle = theme.textTheme.labelLarge?.copyWith(
      color: colors.onSurfaceVariant,
      fontWeight: FontWeight.w600,
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('Meal Logging'),
        centerTitle: false,
      ),
      body: foodProvider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16.0),
              children: [
                Text(
                  'Record your meal',
                  style: theme.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w800,
                    color: colors.onSurface,
                  ),
                ),
                const SizedBox(height: 8.0),
                Text(
                  'Keep track of what you eat and how much you spend.',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: colors.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 16.0),

                // Meal entry form
                Card(
                  margin: EdgeInsets.zero,
                  elevation: 0,
                  color: colors.surfaceContainerLow,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16.0),
                    side: BorderSide(
                      color: colors.outlineVariant.withValues(alpha: 0.7),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Meal details', style: sectionTitleStyle),
                        const SizedBox(height: 16.0),
                        Text('Food', style: fieldLabelStyle),
                        const SizedBox(height: 8.0),
                        DropdownButtonFormField<int>(
                          initialValue: selectedFoodId,
                          isExpanded: true,
                          decoration: const InputDecoration(
                            hintText: 'Choose a food',
                            prefixIcon: Icon(Icons.restaurant_menu),
                          ),
                          items: foodProvider.foods.map((food) {
                            return DropdownMenuItem<int>(
                              value: food.id,
                              child: Text(food.name),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() => selectedFoodId = value);
                          },
                        ),
                        const SizedBox(height: 16.0),
                        Text('Meal type', style: fieldLabelStyle),
                        const SizedBox(height: 8.0),
                        DropdownButtonFormField<String>(
                          initialValue: selectedMealType,
                          decoration: const InputDecoration(
                            prefixIcon: Icon(Icons.schedule),
                          ),
                          items: const [
                            DropdownMenuItem(
                              value: 'Breakfast',
                              child: Text('Breakfast'),
                            ),
                            DropdownMenuItem(
                              value: 'Lunch',
                              child: Text('Lunch'),
                            ),
                            DropdownMenuItem(
                              value: 'Dinner',
                              child: Text('Dinner'),
                            ),
                            DropdownMenuItem(
                              value: 'Snack',
                              child: Text('Snack'),
                            ),
                          ],
                          onChanged: (value) {
                            if (value != null) {
                              setState(() => selectedMealType = value);
                            }
                          },
                        ),
                        const SizedBox(height: 16.0),
                        Text('Number of servings', style: fieldLabelStyle),
                        const SizedBox(height: 8.0),
                        TextField(
                          controller: servingsController,
                          keyboardType: const TextInputType.numberWithOptions(
                            decimal: true,
                          ),
                          decoration: const InputDecoration(
                            hintText: 'Example: 1 or 1.5',
                            prefixIcon: Icon(Icons.restaurant),
                          ),
                        ),
                        const SizedBox(height: 16.0),
                        Text('Price paid', style: fieldLabelStyle),
                        const SizedBox(height: 8.0),
                        TextField(
                          controller: priceController,
                          keyboardType: const TextInputType.numberWithOptions(
                            decimal: true,
                          ),
                          decoration: const InputDecoration(
                            hintText: 'Enter amount paid',
                            prefixIcon: Icon(Icons.payments_outlined),
                            prefixText: '₱ ',
                          ),
                        ),
                        const SizedBox(height: 16.0),
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton.icon(
                            onPressed:
                                mealProvider.isLoading ? null : saveMeal,
                            icon: const Icon(Icons.save_outlined),
                            label: const Text('Save meal'),
                            style: FilledButton.styleFrom(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16.0,
                                vertical: 14.0,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 24.0),

                // Meal history
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        "Today's meal history",
                        style: theme.textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    Icon(
                      Icons.history,
                      color: colors.primary,
                    ),
                  ],
                ),
                const SizedBox(height: 8.0),
                if (mealProvider.isLoading)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24.0),
                    child: Center(child: CircularProgressIndicator()),
                  )
                else if (mealProvider.mealLogs.isEmpty)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      color: colors.surfaceContainerLow,
                      borderRadius: BorderRadius.circular(16.0),
                      border: Border.all(
                        color: colors.outlineVariant.withValues(alpha: 0.7),
                      ),
                    ),
                    child: Column(
                      children: [
                        Icon(
                          Icons.receipt_long_outlined,
                          size: 32.0,
                          color: colors.onSurfaceVariant,
                        ),
                        const SizedBox(height: 8.0),
                        Text(
                          'No meals recorded today yet.',
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: colors.onSurfaceVariant,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  )
                else
                  ...mealProvider.mealLogs.map((meal) {
                    return Card(
                      margin: const EdgeInsets.only(bottom: 8.0),
                      elevation: 0,
                      color: colors.surface,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14.0),
                        side: BorderSide(
                          color: colors.outlineVariant.withValues(alpha: 0.7),
                        ),
                      ),
                      child: ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16.0,
                          vertical: 8.0,
                        ),
                        leading: CircleAvatar(
                          backgroundColor: colors.primaryContainer,
                          foregroundColor: colors.onPrimaryContainer,
                          child: const Icon(Icons.restaurant),
                        ),
                        title: Text(
                          meal.foodName,
                          style: theme.textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        subtitle: Padding(
                          padding: const EdgeInsets.only(top: 4.0),
                          child: Text(
                            '${meal.mealType} • ${meal.servings} serving(s)',
                          ),
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              '₱${meal.pricePaid.toStringAsFixed(2)}',
                              style: theme.textTheme.labelLarge?.copyWith(
                                color: colors.primary,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            IconButton(
                              tooltip: 'Delete meal',
                              icon: Icon(
                                Icons.delete_outline,
                                color: colors.error,
                              ),
                              onPressed: () {
                                mealProvider.deleteMealLog(meal.id!);
                              },
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
              ],
            ),
    );
  }
}
